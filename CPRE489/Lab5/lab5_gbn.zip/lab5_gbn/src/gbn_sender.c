#include "pkt_utils.h"
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>

/* Sends the 26 bytes of the alphabet over the socket described by sockfd to
 * dest. Also, introduces bit error at the rate of ber. */
void gbn_send_alphabet_to(int sockfd, struct sockaddr_in dest, double ber) {
    printf("\n---------Beginning subroutine---------\n");

    // We'll start off with an example of building and sending a single packet of data 0x1234
    char data[] = {0x12, 0x34};
    packet_t packet;
    pkt_build(&packet, PKT_TYPE_DATA, data, 0);
    printf("Built packet: ");
    pkt_print(&packet);

    // Now, let's introduce some bit error into the packet
    introduce_bit_error((char *)packet.bytes, PKT_SIZE, ber);
    printf("Introduced error, now packet is: ");
    pkt_print(&packet);

    // And send it
    sendto(sockfd, packet.bytes, PKT_SIZE, 0, (struct sockaddr *)&dest, sizeof(dest));
    printf("Sent packet\n");

    // And finally, see what the response is from the server/receiver
    packet_t response;
    recvfrom(sockfd, response.bytes, PKT_SIZE, 0, NULL, NULL);
    printf("Received response: ");
    pkt_print(&response);
}